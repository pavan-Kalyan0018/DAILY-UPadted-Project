import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditemdetailComponent } from './additemdetail.component';

describe('AdditemdetailComponent', () => {
  let component: AdditemdetailComponent;
  let fixture: ComponentFixture<AdditemdetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdditemdetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditemdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
