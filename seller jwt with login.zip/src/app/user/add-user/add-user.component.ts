import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {ApiService} from "../../service/api.service";
import { Product } from 'src/app/model/item';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  product:Product=new Product();
  submitted=false;

  constructor(private formBuilder: FormBuilder,private router: Router, private apiService: ApiService) { }

  // addForm: FormGroup;

  ngOnInit() {
    

  }
 

  //  onSubmit() {
  //   this.apiService.createUser(this.addForm.value)
  //      .subscribe( data => {
  //        this.router.navigate(['list-user']);
  // //     });
  // // }
  save(){
   
    this.apiService.addItem(this.product)
    .subscribe(data => { this.router.navigate(['list-user']);
	
   
    });
   }
  
   onSubmit(){
   
    this.submitted=true;
      this.save();
    
  
  
   }

}
