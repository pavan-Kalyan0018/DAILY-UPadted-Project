package com.egg.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "category_details")
public class Category implements Serializable {

	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int categoryid;
	@Column
	private String categoryName;
	private String briefAboutcompany;
	
	public Category() {
		
	}

	public Category(int categoryid, String categoryName, String briefAboutcompany) {
		super();
		this.categoryid = categoryid;
		this.categoryName = categoryName;
		this.briefAboutcompany = briefAboutcompany;
	}

	public int getCategoryid() {
		return categoryid;
	}

	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getBriefAboutcompany() {
		return briefAboutcompany;
	}

	public void setBriefAboutcompany(String briefAboutcompany) {
		this.briefAboutcompany = briefAboutcompany;
	}

	@Override
	public String toString() {
		return "Category [categoryid=" + categoryid + ", categoryName=" + categoryName + ", briefAboutcompany="
				+ briefAboutcompany + "]";
	}
	
	
	
	
}
