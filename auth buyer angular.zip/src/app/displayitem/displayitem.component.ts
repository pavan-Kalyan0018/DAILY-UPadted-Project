import { Component, OnInit } from '@angular/core';
import { Item } from '../items';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-displayitem',
  templateUrl: './displayitem.component.html',
  styleUrls: ['./displayitem.component.css']
})
export class DisplayitemComponent implements OnInit {
  items:Item =new Item();
  ditems:Item[];
  i:any;
  constructor( private pService:ProductService) { }

  ngOnInit(): void {
    this.reloadcartItems();
    console.log(this.ditems);
  }

  reloadcartItems(){
    this.pService.getAllItems().subscribe(ditems => this.ditems=ditems );
  }

  DeleteItems(i){

    console.log("method invoked");
    console.log(i);
    this.pService.DeletingItem(i).subscribe(

      () =>{console.log("deleted Item"); this.reloadcartItems();}, (error) => console.log(error)

    );
  }


}