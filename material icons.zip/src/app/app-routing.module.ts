import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { DisplaycartComponent } from './displaycart/displaycart.component';
import { SearchproductComponent } from './searchproduct/searchproduct.component';
import { BuyersignupComponent } from './buyersignup/buyersignup.component';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { AdditemComponent } from './additem/additem.component';
import { DisplayitemComponent } from './displayitem/displayitem.component';
import { AppComponent } from 'src/app/app.component';
import { HomeComponent } from './home/home.component';
import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser'
import { from } from 'rxjs';


const routes: Routes = [
  {path : 'searchproduct',component:SearchproductComponent},
  {path : 'displaycart' , component:DisplaycartComponent},
  {path : 'buyersignup' , component:BuyersignupComponent},
  {path : 'sellersignup' , component:SellersignupComponent},
  {path : 'additem' , component:AdditemComponent},
  {path : 'displayitem' ,component:DisplayitemComponent},
  {path: 'app',   component:AppComponent},
  {path:'home',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes),BrowserModule,ReactiveFormsModule,FormsModule],
  exports: [RouterModule],
  bootstrap:[AppComponent]
})
export class AppRoutingModule { }
