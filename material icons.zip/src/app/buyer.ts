export class Buyer{
  
    username:string;
    password:string;
    emailId:string;
    mobileNumber:string;
    // "dd-mm-yyyy"
   // createdDate:string;

}