export class Cart {
    
itemId:number;
 quantity:number;
 price:number;

}

export class ViewCart{
  
    cartItemId:number;
itemId:number;
quantity:number;
price:number;
totalprice:number;


}





