export class Transcation {
    transactionId:number;
    transactionType:string;
    dateTime:string;
    remarks:string;
    price:number;

}